package a7;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JPanel;

public class FramePuzzleWidget extends JPanel implements MouseListener,
		KeyListener {

	int gridSize = 5;
	private PictureView[][] picture_view = new PictureView[gridSize][gridSize];

	int blackX = gridSize - 1;
	int blackY = gridSize - 1;

	public FramePuzzleWidget(Picture picture) {
		setLayout(new BorderLayout());

		setLayout(new GridLayout(gridSize, gridSize));

		int sizeViewX = picture.getWidth() / gridSize;
		int sizeViewY = picture.getHeight() / gridSize;

		while (gridSize * sizeViewX < picture.getWidth()) {
			sizeViewX++;

		}

		while (gridSize * sizeViewY < picture.getHeight()) {
			sizeViewY++;

		}

		for (int j = 0; j < gridSize; j++)
			for (int i = 0; i < gridSize; i++) {

				Picture newPic = new PictureImpl(sizeViewX, sizeViewY);

				if ((i + 1) * sizeViewX <= picture.getWidth()
						&& (j + 1) * sizeViewY <= picture.getHeight())

					picture_view[i][j] = new PictureView(picture.extract(
							i * sizeViewX, j * sizeViewY, sizeViewX, sizeViewY)
							.createObservable());

				else {

					FillPicture(newPic, picture, i * sizeViewX, j * sizeViewY,
							sizeViewX, sizeViewY);

					picture_view[i][j] = new PictureView(
							newPic.createObservable());
				}

				add(picture_view[i][j]);
				picture_view[i][j].addMouseListener(this);
				picture_view[i][j].addKeyListener(this);
			}

		Pixel pColor = new ColorPixel(0.0, .4, .75);
		FillPictureWithSolidColor(
				picture_view[gridSize - 1][gridSize - 1].getPicture(), pColor);
	}

	private void FillPictureWithSolidColor(ObservablePicture picture,
			Pixel pColor) {

		for (int x = 0; x < picture.getWidth(); x++)
			for (int y = 0; y < picture.getHeight(); y++)
				picture.setPixel(x, y, pColor);

	}

	private void FillPicture(Picture newPic, Picture picture, int x, int y,
			int sizeViewX, int sizeViewY) {

		for (int j = 0; j < sizeViewY; j++)
			for (int i = 0; i < sizeViewX; i++) {

				Pixel p = null;

				if ((i + x) < picture.getWidth()
						&& (j + y) < picture.getHeight())
					p = picture.getPixel(x + i, y + j);
				else

					p = new ColorPixel(1, 1, 1);

				newPic.setPixel(i, j, p);

			}

	}

	@Override
	public void mouseClicked(MouseEvent e) {

		int newX = 0, newY = 0;
		for (int j = 0; j < gridSize; j++)
			for (int i = 0; i < gridSize; i++) {
				if (picture_view[i][j] == (PictureView) e.getSource()) {
					// System.out.println("You clicked on the view  at: " +i +
					// ","
					// + j + "( " + blackX+ ","+ blackY+")");
					//

					newX = i;
					newY = j;
					break;
				}
			}

		if (blackX == newX && blackY != newY) {

			MoveTileVertical(blackX, blackY, newY);
			blackY = newY;
			// System.out.println("after move  " + "( " + blackX+ ","+
			// blackY+")");
		}

		if (blackX != newX && blackY == newY) {

			MoveTileHozontal(blackX, blackY, newX);

			blackX = newX;
			// System.out.println("after move  " + "( " + blackX+ ","+
			// blackY+")");
		}

	}

	void MoveTileHozontal(int x0, int y, int x1) {

		if (x0 < x1) {
			for (int i = x0; i < x1; i++)
				SwapTile(i, y, i + 1, y);
		} else {
			for (int i = x0; i > x1; i--)
				SwapTile(i, y, i - 1, y);
		}

	}

	void MoveTileVertical(int x, int y0, int y1) {

		if (y0 < y1) {
			for (int i = y0; i < y1; i++)
				SwapTile(x, i, x, i + 1);
		} else {
			for (int i = y0; i > y1; i--)
				SwapTile(x, i, x, i - 1);
		}

	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		// System.out.println("Key pressed " + e.getKeyCode());

		if (e.getKeyCode() == 37)// left
		{
			if (blackX > 0) {
				SwapTile(blackX, blackY, blackX - 1, blackY);

				blackX--;

			}

		}

		if (e.getKeyCode() == 38)// Up
		{
			if (blackY > 0) {
				SwapTile(blackX, blackY, blackX, blackY - 1);

				blackY--;

			}
		}
		if (e.getKeyCode() == 39)// right
		{
			if (blackX < gridSize - 1) {
				SwapTile(blackX, blackY, blackX + 1, blackY);

				blackX++;

			}

		}
		if (e.getKeyCode() == 40)// down
		{
			if (blackY < gridSize - 1) {
				SwapTile(blackX, blackY, blackX, blackY + 1);

				blackY++;

			}

		}

	}

	private void SwapTile(int x0, int y0, int x1, int y1) {

		ObservablePicture p = picture_view[x0][y0].getPicture();

		picture_view[x0][y0].setPicture(picture_view[x1][y1].getPicture());

		picture_view[x1][y1].setPicture(p);

	}

	@Override
	public void keyReleased(KeyEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub

	}

}
