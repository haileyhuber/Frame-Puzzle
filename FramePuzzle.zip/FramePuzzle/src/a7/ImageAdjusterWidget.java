package a7;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class ImageAdjusterWidget extends JPanel implements ChangeListener {

	Picture picture = null;
	private PictureView picture_view;
	JSlider blur_slider = new JSlider(JSlider.HORIZONTAL, 0, 5, 0);
	JSlider saturation_slider = new JSlider(JSlider.HORIZONTAL, -100, 100, 0);
	JSlider brightness_slider = new JSlider(JSlider.HORIZONTAL, -100, 100, 0);
	static private JPanel sliderPanel = new JPanel();

	public ImageAdjusterWidget(Picture p) {
		picture_view = new PictureView(p.createObservable());
		SaveOriginalPicture(p);

		setLayout(new BorderLayout());
		add(picture_view, BorderLayout.CENTER);

		blur_slider.setMajorTickSpacing(1);
		blur_slider.setPaintTicks(true);
		blur_slider.setPaintLabels(true);
		blur_slider.setSnapToTicks(true);
		blur_slider.setName("Blur:");
		saturation_slider.addChangeListener(this);

		saturation_slider.setMajorTickSpacing(25);
		saturation_slider.setPaintTicks(true);
		saturation_slider.setPaintLabels(true);

		brightness_slider.setMajorTickSpacing(25);
		brightness_slider.setPaintTicks(true);
		brightness_slider.setPaintLabels(true);

		addSlider(blur_slider, "Blur:", this);
		addSlider(saturation_slider, "Saturation:", this);
		addSlider(brightness_slider, "Brightness:", this);

		sliderPanel.setLayout(new GridLayout(3, 1));
		add(sliderPanel, BorderLayout.SOUTH);

	}

	@Override
	public void stateChanged(ChangeEvent e) {

		int blurLevel = (int) blur_slider.getValue();
		Picture changedPic = CopylPicture(picture);

		BlurImage(blurLevel, changedPic);

		int brightness = (int) brightness_slider.getValue();

		brightness(brightness, changedPic);

		int satuIndex = (int) saturation_slider.getValue();

		saturation(satuIndex, changedPic);

		picture_view.setPicture(changedPic.createObservable());

	}

	private void saturation(int saturationLevel, Picture pic) {

		for (int i = 0; pic.getWidth() > i; i++) {
			for (int j = 0; pic.getHeight() > j; j++) {

				double red = 0.0, green = 0.0, blue = 0.0;

				if (saturationLevel != 0) {
					Pixel p = pic.getPixel(i, j);

					if (saturationLevel > 0) {
						double a = Math.max(p.getRed(), p.getGreen());
						a = Math.max(a, p.getBlue());

						if (a > 0) {
							red = p.getRed()
									* ((a + ((1.0 - a) * (saturationLevel / 100.0))) / a);
							green = p.getGreen()
									* ((a + ((1.0 - a) * (saturationLevel / 100.0))) / a);
							blue = p.getBlue()
									* ((a + ((1.0 - a) * (saturationLevel / 100.0))) / a);

						}

					} else {
						red = p.getRed() * (1.0 + (saturationLevel / 100.0))
								- (p.getIntensity() * saturationLevel / 100.0);
						green = p.getGreen()
								* (1.0 + (saturationLevel / 100.0))
								- (p.getIntensity() * saturationLevel / 100.0);
						blue = p.getBlue() * (1.0 + (saturationLevel / 100.0))
								- (p.getIntensity() * saturationLevel / 100.0);
					}

					p = new ColorPixel(red, green, blue);

					pic.setPixel(i, j, p);
				}

			}

		}
	}

	private void brightness(int brightnessLevel, Picture pic) {
		
		for (int i = 0; pic.getWidth() > i; i++) {
			for (int j = 0; pic.getHeight() > j; j++) {

				Pixel p = pic.getPixel(i, j);
				if (brightnessLevel != 0) {

					p = new ColorPixel(BrightColor(brightnessLevel, p.getRed()),
							BrightColor(brightnessLevel, p.getGreen()), BrightColor(
									brightnessLevel, p.getBlue()));

					pic.setPixel(i, j, p);
				}

			}

		}
	}

	double BrightColor(int n, double original) {
		double d = original;

		if (n > 0) {
			d = d + (1 - d) * n / 100.00;
		}

		if (n < 0) {
			d = d + (d) * n / 100.00;
		}

		if (d > 1.0)
			d = 1.0;
		if (d < 0)
			d = 0.0;

		return d;
	}

	void BlurImage(int n, Picture copy) {

		for (int i = 0; picture.getWidth() > i; i++) {

			for (int j = 0; picture.getHeight() > j; j++) {

				Pixel p = picture.getPixel(i, j);
				if (n > 0)
					p = BlurPixel(i, j, picture, n);
				copy.setPixel(i, j, p);

			}

		}

	}

	private Pixel BlurPixel(int i, int j, Picture pic, int blurIndex) {

		double red, blue, green;

		red = 0.0;
		blue = 0.0;
		green = 0.0;

		int n = 0;

		for (int x = i - blurIndex; x <= i + blurIndex; x++)
			for (int y = j - blurIndex; y <= j + blurIndex; y++) {

				if (x >= 0 && y >= 0 && x < pic.getWidth()
						&& y < pic.getHeight() && !(i == x && j == y)) {
					n++;
					red += pic.getPixel(x, y).getRed();
					green += pic.getPixel(x, y).getGreen();
					blue += pic.getPixel(x, y).getBlue();

				}
			}

		Pixel p = new ColorPixel(red / n, green / n, blue / n);

		return p;
	}

	public void addSlider(JSlider s, String description,
			ImageAdjusterWidget listener) {
		s.addChangeListener(listener);
		JPanel panel = new JPanel();
		panel.add(new JLabel(description));
		panel.add(s);
		sliderPanel.add(panel);
	}

	void SaveOriginalPicture(Picture pic) {
		picture = CopylPicture(pic);
	}

	Picture CopylPicture(Picture pic) {
		Picture copy = new PictureImpl(pic.getWidth(), pic.getHeight());

		for (int i = 0; pic.getWidth() > i; i++) {

			for (int j = 0; pic.getHeight() > j; j++) {

				Pixel pixel = pic.getPixel(i, j);

				pixel = new ColorPixel(pixel.getRed(), pixel.getGreen(),
						pixel.getBlue());

				copy.setPixel(i, j, pixel);

			}

		}

		return copy;
	}

}
