package a7;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class PixelInspectorWidget extends JPanel implements MouseListener {

	private PictureView picture_view;
	JTextArea title_label = new JTextArea();

	public PixelInspectorWidget(Picture picture) {
		setLayout(new BorderLayout());

		picture_view = new PictureView(picture.createObservable());
		picture_view.addMouseListener(this);
		add(picture_view, BorderLayout.CENTER);

		Dimension d = new Dimension(500, 300);

		title_label.setMinimumSize(d);
		title_label.setText("\n X: \n\n Y: \n\n Red: \n\n Green:\n\n Blue: \n\n Brightness: ");
		add(title_label, BorderLayout.WEST);

		this.setMinimumSize(new Dimension(500, 500));
	}

	@Override
	public void mouseClicked(MouseEvent e) {

		if (e.getX() < picture_view.getPicture().getWidth()
				&& e.getY() < picture_view.getPicture().getHeight()) {
			Pixel p = picture_view.getPicture().getPixel(e.getX(), e.getY());
			title_label.setText(String.format("\n X:%d \n\n Y:%d \n\n Red:%3.2f \n\n Green:%3.2f\n\n Blue:%3.2f \n\n Brightness:%3.2f ",
									+e.getX(), e.getY(), p.getRed(),
									p.getGreen(), p.getBlue(), p.getIntensity()));

		} else
			title_label.setText("ERROR: click outside picture");
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub

	}

}
